Follow the following steps to setup project locally:
```
Clone the project in your local machine.
Run the following commands:
  composer install
  bin/console doctrine:schema:create
then, run this command to run project locally:
  symfony server:start
```

NOTE: Please refer symfony documentation for pre-requisites of above commands.
